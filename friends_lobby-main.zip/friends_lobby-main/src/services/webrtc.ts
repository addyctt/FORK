import SimplePeer from 'simple-peer';
import { useEffect, useState, useRef, useCallback } from 'react';
import { doc, updateDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/firebase';

interface PeerConnection {
  peerId: string;
  peer: SimplePeer.Instance;
  stream?: MediaStream;
}

interface SignalData {
  type: string;
  sdp?: string;
  candidate?: RTCIceCandidate;
}

export function useVoiceChat(lobbyId: string, userId: string) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [peers, setPeers] = useState<PeerConnection[]>([]);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const peersRef = useRef<PeerConnection[]>([]);
  const localStreamRef = useRef<MediaStream | null>(null);

  // Initialize local media stream
  const initLocalStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false
      });
      
      setLocalStream(stream);
      localStreamRef.current = stream;
      return stream;
    } catch (err) {
      setError('Could not access microphone. Please check your permissions.');
      console.error('Error accessing media devices:', err);
      return null;
    }
  };

  // Create a new peer connection
  const createPeer = useCallback((targetId: string, initiator: boolean, stream: MediaStream) => {
    const peer = new SimplePeer({
      initiator,
      stream,
      trickle: true,
      config: {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:global.stun.twilio.com:3478' }
        ]
      }
    });

    // Handle signaling through Firestore
    peer.on('signal', async (data: SignalData) => {
      try {
        await updateDoc(doc(db, 'lobbies', lobbyId, 'signals', targetId), {
          [`${userId}`]: {
            type: data.type,
            sdp: data.sdp,
            candidate: data.candidate,
            timestamp: Date.now()
          }
        });
      } catch (error) {
        console.error('Error sending signal:', error);
      }
    });

    peer.on('stream', (remoteStream: MediaStream) => {
      const audioContext = new AudioContext();
      const source = audioContext.createMediaStreamSource(remoteStream);
      const destination = audioContext.createMediaStreamDestination();
      source.connect(destination);
    });

    peer.on('error', (err: Error) => {
      console.error('Peer connection error:', err);
      removePeer(targetId);
    });

    return {
      peerId: targetId,
      peer
    };
  }, [lobbyId, userId]);

  // Add a new peer to the peers list
  const addPeer = useCallback((peerConnection: PeerConnection) => {
    setPeers(prevPeers => {
      const newPeers = prevPeers.filter(p => p.peerId !== peerConnection.peerId);
      return [...newPeers, peerConnection];
    });
    peersRef.current = [...peersRef.current.filter(p => p.peerId !== peerConnection.peerId), peerConnection];
  }, []);

  // Remove a peer from the peers list
  const removePeer = useCallback((peerId: string) => {
    setPeers(prevPeers => {
      const peerToRemove = prevPeers.find(p => p.peerId === peerId);
      if (peerToRemove) {
        peerToRemove.peer.destroy();
      }
      return prevPeers.filter(p => p.peerId !== peerId);
    });
    peersRef.current = peersRef.current.filter(p => p.peerId !== peerId);
  }, []);

  // Listen for signaling data
  useEffect(() => {
    if (!lobbyId || !userId || !connected) return;

    const unsubscribe = onSnapshot(
      doc(db, 'lobbies', lobbyId, 'signals', userId),
      (snapshot) => {
        const data = snapshot.data();
        if (!data) return;

        Object.entries(data).forEach(([peerId, signal]) => {
          if (peerId === userId) return;

          const existingPeer = peersRef.current.find(p => p.peerId === peerId);
          if (existingPeer) {
            try {
              existingPeer.peer.signal(signal);
            } catch (error) {
              console.error('Error processing signal:', error);
            }
          } else if (localStreamRef.current) {
            const newPeer = createPeer(peerId, false, localStreamRef.current);
            newPeer.peer.signal(signal);
            addPeer(newPeer);
          }
        });
      }
    );

    return () => {
      unsubscribe();
    };
  }, [lobbyId, userId, connected, createPeer, addPeer]);

  // Connect to voice chat
  const connect = async () => {
    const stream = await initLocalStream();
    if (!stream) return;
    
    setConnected(true);

    // Create initial peer connections
    try {
      const lobbyDoc = await doc(db, 'lobbies', lobbyId);
      await updateDoc(lobbyDoc, {
        [`participants.${userId}.isConnected`]: true
      });
    } catch (error) {
      console.error('Error updating connection status:', error);
    }
  };

  // Disconnect from voice chat
  const disconnect = async () => {
    peers.forEach(({ peer }) => {
      peer.destroy();
    });

    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }

    setPeers([]);
    peersRef.current = [];
    setLocalStream(null);
    localStreamRef.current = null;
    setConnected(false);

    try {
      const lobbyDoc = await doc(db, 'lobbies', lobbyId);
      await updateDoc(lobbyDoc, {
        [`participants.${userId}.isConnected`]: false
      });
    } catch (error) {
      console.error('Error updating connection status:', error);
    }
  };

  // Toggle mute for local stream
  const toggleMute = (muted: boolean) => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !muted;
      });
    }
  };

  return {
    localStream,
    peers,
    connected,
    error,
    connect,
    disconnect,
    toggleMute
  };
}