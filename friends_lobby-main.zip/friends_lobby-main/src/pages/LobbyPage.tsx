import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Copy, CheckCircle } from 'lucide-react';
import { useLobby } from '../contexts/LobbyContext';
import { useNotifications } from '../contexts/NotificationContext';
import Sidebar from '../components/layout/Sidebar';
import ParticipantList from '../components/lobby/ParticipantList';
import VoiceControls from '../components/lobby/VoiceControls';
import ProfileModal from '../components/profile/ProfileModal';

function LobbyPage() {
  const { lobbyId } = useParams<{ lobbyId: string }>();
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const { currentLobby, leaveLobby } = useLobby();
  const { addNotification } = useNotifications();
  const navigate = useNavigate();

  useEffect(() => {
    // Cleanup when unmounting
    return () => {
      // This will be called when navigating away from the lobby page
    };
  }, []);

  const handleLeaveLobby = async () => {
    try {
      await leaveLobby();
      navigate('/');
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to leave lobby',
        type: 'error',
        autoClose: 5000
      });
    }
  };

  const copyLobbyCode = () => {
    if (!currentLobby) return;
    
    navigator.clipboard.writeText(currentLobby.code);
    setCopied(true);
    
    addNotification({
      title: 'Success',
      message: 'Lobby code copied to clipboard',
      type: 'success',
      autoClose: 2000
    });
    
    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar 
        onProfileClick={() => setIsProfileModalOpen(true)}
      />
      
      <main className="flex flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-border bg-card px-6 py-4">
          <div className="flex items-center">
            <button
              onClick={handleLeaveLobby}
              className="mr-4 rounded-lg p-2 text-muted hover:bg-input hover:text-foreground"
              aria-label="Leave lobby"
            >
              <ArrowLeft size={20} />
            </button>
            
            <div>
              <h1 className="text-lg font-semibold text-foreground">
                {currentLobby?.name || 'Voice Lobby'}
              </h1>
              <div className="flex items-center">
                <span className="text-sm text-muted">Code: {currentLobby?.code}</span>
                <button
                  onClick={copyLobbyCode}
                  className="ml-2 rounded-md p-1 text-muted hover:text-foreground"
                  aria-label="Copy lobby code"
                >
                  {copied ? (
                    <CheckCircle size={16} className="text-success" />
                  ) : (
                    <Copy size={16} />
                  )}
                </button>
              </div>
            </div>
          </div>
          
          <div>
            <span className="rounded-full bg-success px-2 py-1 text-xs font-medium text-white">
              Live
            </span>
          </div>
        </header>
        
        <div className="flex flex-1 flex-col overflow-hidden p-4">
          <div className="mb-4 rounded-xl bg-card p-4 shadow-md">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Participants</h2>
            <ParticipantList />
          </div>
          
          <div className="mt-auto rounded-xl bg-card p-4 shadow-md">
            <VoiceControls />
          </div>
        </div>
      </main>
      
      {isProfileModalOpen && (
        <ProfileModal onClose={() => setIsProfileModalOpen(false)} />
      )}
    </div>
  );
}

export default LobbyPage;