import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { SearchIcon } from 'lucide-react';
import { useLobby } from '../contexts/LobbyContext';
import { useNotifications } from '../contexts/NotificationContext';
import Sidebar from '../components/layout/Sidebar';
import ProfileModal from '../components/profile/ProfileModal';

function HomePage() {
  const [lobbyCode, setLobbyCode] = useState('');
  const [joining, setJoining] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  
  const { joinLobbyByCode } = useLobby();
  const { addNotification } = useNotifications();
  const navigate = useNavigate();

  const handleJoinLobby = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!lobbyCode.trim()) {
      addNotification({
        title: 'Error',
        message: 'Please enter a lobby code',
        type: 'error',
        autoClose: 3000
      });
      return;
    }
    
    setJoining(true);
    
    try {
      const lobbyId = await joinLobbyByCode(lobbyCode.trim());
      navigate(`/lobby/${lobbyId}`);
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to join lobby',
        type: 'error',
        autoClose: 5000
      });
    } finally {
      setJoining(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar 
        onProfileClick={() => setIsProfileModalOpen(true)}
      />
      
      <main className="flex flex-1 flex-col">
        <div className="flex h-full items-center justify-center p-4">
          <div className="max-w-md rounded-xl bg-card p-8 shadow-lg">
            <h1 className="mb-6 text-center text-2xl font-bold text-foreground">
              Join a Voice Lobby
            </h1>
            
            <form onSubmit={handleJoinLobby} className="space-y-4">
              <div className="form-group">
                <label htmlFor="lobbyCode" className="form-label">
                  Lobby Code
                </label>
                <div className="relative">
                  <input
                    id="lobbyCode"
                    type="text"
                    value={lobbyCode}
                    onChange={(e) => setLobbyCode(e.target.value.toUpperCase())}
                    className="input w-full pl-10"
                    placeholder="Enter lobby code"
                    disabled={joining}
                    autoComplete="off"
                  />
                  <SearchIcon className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
                </div>
              </div>
              
              <button
                type="submit"
                className="btn btn-primary w-full"
                disabled={joining}
              >
                {joining ? 'Joining...' : 'Join Lobby'}
              </button>
            </form>
            
            <div className="mt-4 text-center text-sm text-muted">
              or invite friends from the sidebar to create a new lobby
            </div>
          </div>
        </div>
      </main>
      
      {isProfileModalOpen && (
        <ProfileModal onClose={() => setIsProfileModalOpen(false)} />
      )}
    </div>
  );
}

export default HomePage;