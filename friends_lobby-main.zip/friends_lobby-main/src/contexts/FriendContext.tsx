import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  collection, 
  query, 
  where, 
  getDocs, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  arrayUnion, 
  arrayRemove, 
  onSnapshot,
  deleteDoc
} from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { useAuth } from './AuthContext';

interface FriendRequest {
  id: string;
  senderId: string;
  receiverId: string;
  senderName: string;
  senderPhoto: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
}

interface Friend {
  uid: string;
  username: string;
  displayName?: string;
  photoURL: string;
  isOnline: boolean;
  inLobby?: string | null;
}

interface FriendContextType {
  friends: Friend[];
  friendRequests: FriendRequest[];
  sendFriendRequest: (username: string) => Promise<void>;
  acceptFriendRequest: (requestId: string) => Promise<void>;
  rejectFriendRequest: (requestId: string) => Promise<void>;
  removeFriend: (friendId: string) => Promise<void>;
  loading: boolean;
}

const FriendContext = createContext<FriendContextType | undefined>(undefined);

export function useFriends() {
  const context = useContext(FriendContext);
  if (context === undefined) {
    throw new Error('useFriends must be used within a FriendProvider');
  }
  return context;
}

export function FriendProvider({ children }: { children: ReactNode }) {
  const { currentUser, userProfile } = useAuth();
  const [friends, setFriends] = useState<Friend[]>([]);
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
  const [loading, setLoading] = useState(true);

  // Listen for friend list changes
  useEffect(() => {
    if (!currentUser || !userProfile) {
      setFriends([]);
      setLoading(false);
      return () => {};
    }

    setLoading(true);

    // Listen to user's friends
    const unsubscribeFriends = onSnapshot(
      collection(db, 'users'),
      async (snapshot) => {
        if (userProfile.friends && userProfile.friends.length > 0) {
          const friendsData = snapshot.docs
            .filter((doc) => userProfile.friends.includes(doc.id))
            .map((doc) => {
              const userData = doc.data();
              return {
                uid: doc.id,
                username: userData.username,
                displayName: userData.displayName,
                photoURL: userData.photoURL,
                isOnline: userData.isOnline || false,
                inLobby: userData.inLobby || null
              };
            });
          setFriends(friendsData);
        } else {
          setFriends([]);
        }
        setLoading(false);
      }
    );

    // Listen to incoming friend requests
    const unsubscribeRequests = onSnapshot(
      query(
        collection(db, 'friendRequests'),
        where('receiverId', '==', currentUser.uid),
        where('status', '==', 'pending')
      ),
      (snapshot) => {
        const requests = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data()
        })) as FriendRequest[];
        setFriendRequests(requests);
      }
    );

    return () => {
      unsubscribeFriends();
      unsubscribeRequests();
    };
  }, [currentUser, userProfile]);

  // Send a friend request
  const sendFriendRequest = async (username: string) => {
    if (!currentUser || !userProfile) return;

    try {
      // Find user by username
      const usernameDoc = await getDoc(doc(db, 'usernames', username));
      if (!usernameDoc.exists()) {
        throw new Error('User not found');
      }

      const targetUserId = usernameDoc.data().uid;

      // Don't allow sending request to self
      if (targetUserId === currentUser.uid) {
        throw new Error('You cannot send a friend request to yourself');
      }

      // Check if already friends
      const targetUserDoc = await getDoc(doc(db, 'users', targetUserId));
      if (!targetUserDoc.exists()) {
        throw new Error('User not found');
      }

      const targetUserData = targetUserDoc.data();
      if (targetUserData.friends && targetUserData.friends.includes(currentUser.uid)) {
        throw new Error('You are already friends with this user');
      }

      // Check if request already exists
      const existingRequests = await getDocs(
        query(
          collection(db, 'friendRequests'),
          where('senderId', '==', currentUser.uid),
          where('receiverId', '==', targetUserId)
        )
      );

      if (!existingRequests.empty) {
        throw new Error('Friend request already sent');
      }

      // Create friend request
      const requestData: Omit<FriendRequest, 'id'> = {
        senderId: currentUser.uid,
        receiverId: targetUserId,
        senderName: userProfile.username,
        senderPhoto: userProfile.photoURL,
        status: 'pending',
        createdAt: Date.now()
      };

      await setDoc(doc(collection(db, 'friendRequests')), requestData);
    } catch (error) {
      console.error('Error sending friend request:', error);
      throw error;
    }
  };

  // Accept a friend request
  const acceptFriendRequest = async (requestId: string) => {
    if (!currentUser || !userProfile) return;

    try {
      const requestDoc = await getDoc(doc(db, 'friendRequests', requestId));
      if (!requestDoc.exists()) {
        throw new Error('Friend request not found');
      }

      const request = requestDoc.data() as Omit<FriendRequest, 'id'>;
      
      // Ensure the request is for the current user
      if (request.receiverId !== currentUser.uid) {
        throw new Error('Unauthorized');
      }

      // Update friend lists for both users
      await updateDoc(doc(db, 'users', currentUser.uid), {
        friends: arrayUnion(request.senderId)
      });

      await updateDoc(doc(db, 'users', request.senderId), {
        friends: arrayUnion(currentUser.uid)
      });

      // Update request status
      await updateDoc(doc(db, 'friendRequests', requestId), {
        status: 'accepted'
      });
    } catch (error) {
      console.error('Error accepting friend request:', error);
      throw error;
    }
  };

  // Reject a friend request
  const rejectFriendRequest = async (requestId: string) => {
    if (!currentUser) return;

    try {
      const requestDoc = await getDoc(doc(db, 'friendRequests', requestId));
      if (!requestDoc.exists()) {
        throw new Error('Friend request not found');
      }

      const request = requestDoc.data() as Omit<FriendRequest, 'id'>;
      
      // Ensure the request is for the current user
      if (request.receiverId !== currentUser.uid) {
        throw new Error('Unauthorized');
      }

      // Update request status
      await updateDoc(doc(db, 'friendRequests', requestId), {
        status: 'rejected'
      });
    } catch (error) {
      console.error('Error rejecting friend request:', error);
      throw error;
    }
  };

  // Remove a friend
  const removeFriend = async (friendId: string) => {
    if (!currentUser || !userProfile) return;

    try {
      // Remove from both users' friend lists
      await updateDoc(doc(db, 'users', currentUser.uid), {
        friends: arrayRemove(friendId)
      });

      await updateDoc(doc(db, 'users', friendId), {
        friends: arrayRemove(currentUser.uid)
      });

      // Clean up any existing friend requests
      const requests = await getDocs(
        query(
          collection(db, 'friendRequests'),
          where('senderId', 'in', [currentUser.uid, friendId]),
          where('receiverId', 'in', [currentUser.uid, friendId])
        )
      );

      const batch = requests.docs.map((doc) => {
        return deleteDoc(doc.ref);
      });

      await Promise.all(batch);
    } catch (error) {
      console.error('Error removing friend:', error);
      throw error;
    }
  };

  const value = {
    friends,
    friendRequests,
    sendFriendRequest,
    acceptFriendRequest,
    rejectFriendRequest,
    removeFriend,
    loading
  };

  return (
    <FriendContext.Provider value={value}>
      {children}
    </FriendContext.Provider>
  );
}