import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  GoogleAuthProvider, 
  FacebookAuthProvider,
  OAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User 
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { auth, db, storage } from '../firebase/firebase';

interface UserProfile {
  uid: string;
  username: string;
  displayName?: string;
  email: string;
  photoURL: string;
  createdAt: number;
  friends: string[];
}

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithFacebook: () => Promise<void>;
  signInWithApple: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (email: string, password: string) => Promise<void>;
  logOut: () => Promise<void>;
  updateProfile: (data: Partial<UserProfile>, photoFile?: File) => Promise<void>;
  setupUsername: (username: string, photoFile?: File) => Promise<void>;
  checkUsernameAvailability: (username: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Listen to auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      
      if (user) {
        try {
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists()) {
            setUserProfile(userDoc.data() as UserProfile);
          } else {
            setUserProfile(null);
          }
        } catch (error) {
          console.error('Error fetching user profile:', error);
        }
      } else {
        setUserProfile(null);
      }
      
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  // Check for redirect result on mount
  useEffect(() => {
    getRedirectResult(auth).catch((error) => {
      console.error('Error getting redirect result:', error);
    });
  }, []);

  // Sign in with Google
  const signInWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      // If popup is blocked, fall back to redirect
      if (error.code === 'auth/popup-blocked') {
        await signInWithRedirect(auth, provider);
      } else {
        console.error('Error signing in with Google:', error);
        throw error;
      }
    }
  };

  // Sign in with Facebook
  const signInWithFacebook = async () => {
    try {
      const provider = new FacebookAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      // If popup is blocked, fall back to redirect
      if (error.code === 'auth/popup-blocked') {
        await signInWithRedirect(auth, provider);
      } else {
        console.error('Error signing in with Facebook:', error);
        throw error;
      }
    }
  };

  // Sign in with Apple
  const signInWithApple = async () => {
    try {
      const provider = new OAuthProvider('apple.com');
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      // If popup is blocked, fall back to redirect
      if (error.code === 'auth/popup-blocked') {
        await signInWithRedirect(auth, provider);
      } else {
        console.error('Error signing in with Apple:', error);
        throw error;
      }
    }
  };

  // Sign in with email and password
  const signInWithEmail = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
      console.error('Error signing in with email:', error);
      throw error;
    }
  };

  // Sign up with email and password
  const signUpWithEmail = async (email: string, password: string) => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (error) {
      console.error('Error signing up with email:', error);
      throw error;
    }
  };

  // Log out
  const logOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Error signing out:', error);
      throw error;
    }
  };

  // Check if username is available
  const checkUsernameAvailability = async (username: string) => {
    try {
      // Check if username is already taken
      const usersSnapshot = await getDoc(doc(db, 'usernames', username));
      return !usersSnapshot.exists();
    } catch (error) {
      console.error('Error checking username availability:', error);
      throw error;
    }
  };

  // Upload profile photo and get URL
  const uploadProfilePhoto = async (file: File, uid: string) => {
    try {
      const storageRef = ref(storage, `profilePhotos/${uid}`);
      const snapshot = await uploadBytes(storageRef, file);
      return await getDownloadURL(snapshot.ref);
    } catch (error) {
      console.error('Error uploading profile photo:', error);
      throw error;
    }
  };

  // Set up username and profile photo
  const setupUsername = async (username: string, photoFile?: File) => {
    if (!currentUser) return;

    try {
      // Check if username is available
      const isAvailable = await checkUsernameAvailability(username);
      if (!isAvailable) {
        throw new Error('Username is already taken');
      }

      // Upload profile photo if provided
      let photoURL = currentUser.photoURL || '';
      if (photoFile) {
        photoURL = await uploadProfilePhoto(photoFile, currentUser.uid);
      }

      // Create user profile
      const userProfileData: UserProfile = {
        uid: currentUser.uid,
        username,
        displayName: currentUser.displayName || '',
        email: currentUser.email || '',
        photoURL,
        createdAt: Date.now(),
        friends: []
      };

      // Save user profile
      await setDoc(doc(db, 'users', currentUser.uid), userProfileData);
      
      // Reserve username
      await setDoc(doc(db, 'usernames', username), { uid: currentUser.uid });

      setUserProfile(userProfileData);
    } catch (error) {
      console.error('Error setting up username:', error);
      throw error;
    }
  };

  // Update user profile
  const updateProfile = async (data: Partial<UserProfile>, photoFile?: File) => {
    if (!currentUser || !userProfile) return;

    try {
      // Upload new profile photo if provided
      let photoURL = userProfile.photoURL;
      if (photoFile) {
        photoURL = await uploadProfilePhoto(photoFile, currentUser.uid);
      }

      // Update profile data
      const updatedProfile = {
        ...data,
        photoURL: photoURL
      };

      // If username is changed, check availability and update usernames collection
      if (data.username && data.username !== userProfile.username) {
        const isAvailable = await checkUsernameAvailability(data.username);
        if (!isAvailable) {
          throw new Error('Username is already taken');
        }

        // Reserve new username
        await setDoc(doc(db, 'usernames', data.username), { uid: currentUser.uid });
        
        // Delete old username reservation
        // This step would typically use a transaction or batch write in a production app
      }

      // Update user document
      await updateDoc(doc(db, 'users', currentUser.uid), updatedProfile);
      
      // Update local state
      setUserProfile({ ...userProfile, ...updatedProfile });
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  };

  const value = {
    currentUser,
    userProfile,
    loading,
    signInWithGoogle,
    signInWithFacebook,
    signInWithApple,
    signInWithEmail,
    signUpWithEmail,
    logOut,
    updateProfile,
    setupUsername,
    checkUsernameAvailability
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}