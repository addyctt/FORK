import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  doc, 
  collection, 
  addDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  arrayUnion, 
  arrayRemove, 
  onSnapshot, 
  deleteDoc, 
  query, 
  where 
} from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../firebase/firebase';
import { useAuth } from './AuthContext';
import { useNotifications } from './NotificationContext';

interface LobbyParticipant {
  uid: string;
  username: string;
  displayName?: string;
  photoURL: string;
  isMuted: boolean;
  isHost: boolean;
}

interface Lobby {
  id: string;
  name: string;
  hostId: string;
  participants: LobbyParticipant[];
  createdAt: number;
  code: string;
}

interface LobbyInvite {
  id: string;
  lobbyId: string;
  lobbyName: string;
  inviterId: string;
  inviterName: string;
  inviteeId: string;
  createdAt: number;
}

interface LobbyContextType {
  currentLobby: Lobby | null;
  createLobby: (name?: string) => Promise<string>;
  joinLobbyByCode: (code: string) => Promise<string>;
  joinLobbyById: (lobbyId: string) => Promise<void>;
  leaveLobby: () => Promise<void>;
  inviteFriend: (friendId: string) => Promise<void>;
  kickParticipant: (participantId: string) => Promise<void>;
  toggleMute: (participantId: string, muted: boolean) => Promise<void>;
  loading: boolean;
}

const LobbyContext = createContext<LobbyContextType | undefined>(undefined);

export function useLobby() {
  const context = useContext(LobbyContext);
  if (context === undefined) {
    throw new Error('useLobby must be used within a LobbyProvider');
  }
  return context;
}

export function LobbyProvider({ children }: { children: ReactNode }) {
  const { currentUser, userProfile } = useAuth();
  const { addNotification } = useNotifications();
  const [currentLobby, setCurrentLobby] = useState<Lobby | null>(null);
  const [loading, setLoading] = useState(true);

  // Track online status
  useEffect(() => {
    if (!currentUser) return;

    const userStatusRef = doc(db, 'users', currentUser.uid);
    
    // Update online status when connecting
    const updateOnlineStatus = async () => {
      await updateDoc(userStatusRef, {
        isOnline: true,
        lastSeen: Date.now()
      });
    };

    // Update offline status when disconnecting
    const updateOfflineStatus = async () => {
      await updateDoc(userStatusRef, {
        isOnline: false,
        lastSeen: Date.now()
      });
    };

    // Set up presence tracking
    updateOnlineStatus();
    window.addEventListener('beforeunload', updateOfflineStatus);
    
    // Set up periodic heartbeat
    const heartbeatInterval = setInterval(updateOnlineStatus, 30000);

    return () => {
      window.removeEventListener('beforeunload', updateOfflineStatus);
      clearInterval(heartbeatInterval);
      updateOfflineStatus();
    };
  }, [currentUser]);

  // Listen for lobby changes if user is in a lobby
  useEffect(() => {
    if (!currentUser) {
      setCurrentLobby(null);
      setLoading(false);
      return () => {};
    }

    setLoading(true);

    // Check if user is in a lobby
    const userDocRef = doc(db, 'users', currentUser.uid);
    
    const unsubscribeUser = onSnapshot(userDocRef, async (userDoc) => {
      if (userDoc.exists()) {
        const userData = userDoc.data();
        
        if (userData.inLobby) {
          // User is in a lobby, listen to that lobby
          const lobbyDocRef = doc(db, 'lobbies', userData.inLobby);
          
          const unsubscribeLobby = onSnapshot(lobbyDocRef, (lobbyDoc) => {
            if (lobbyDoc.exists()) {
              const lobbyData = lobbyDoc.data();
              setCurrentLobby({
                id: lobbyDoc.id,
                name: lobbyData.name,
                hostId: lobbyData.hostId,
                participants: lobbyData.participants,
                createdAt: lobbyData.createdAt,
                code: lobbyData.code
              });
            } else {
              // Lobby doesn't exist anymore, update user
              updateDoc(userDocRef, { inLobby: null });
              setCurrentLobby(null);
            }
            setLoading(false);
          });
          
          return () => unsubscribeLobby();
        } else {
          setCurrentLobby(null);
          setLoading(false);
        }
      }
    });

    // Listen for lobby invites
    let unsubscribeInvites: () => void = () => {};
    
    if (currentUser) {
      const invitesQuery = query(
        collection(db, 'lobbyInvites'),
        where('inviteeId', '==', currentUser.uid)
      );
      
      unsubscribeInvites = onSnapshot(invitesQuery, (snapshot) => {
        snapshot.docChanges().forEach((change) => {
          if (change.type === 'added') {
            const invite = change.doc.data() as LobbyInvite;
            
            // Add notification for new invite
            addNotification({
              id: invite.id,
              title: 'Lobby Invite',
              message: `${invite.inviterName} invited you to join their lobby`,
              type: 'invite',
              data: {
                lobbyId: invite.lobbyId,
                inviteId: change.doc.id
              },
              autoClose: 5000
            });
            
            // Auto-delete invite after 5 seconds
            setTimeout(() => {
              deleteDoc(doc(db, 'lobbyInvites', change.doc.id))
                .catch((error) => console.error('Error deleting invite:', error));
            }, 5000);
          }
        });
      });
    }

    return () => {
      unsubscribeUser();
      unsubscribeInvites();
    };
  }, [currentUser, addNotification]);

  // Create a new lobby
  const createLobby = async (name?: string) => {
    if (!currentUser || !userProfile) throw new Error('User not authenticated');

    try {
      // Generate a unique code for the lobby
      const code = Math.random().toString(36).substring(2, 8).toUpperCase();
      
      // Create participant object for the host
      const hostParticipant: LobbyParticipant = {
        uid: currentUser.uid,
        username: userProfile.username,
        displayName: userProfile.displayName,
        photoURL: userProfile.photoURL,
        isMuted: false,
        isHost: true
      };
      
      // Create lobby document
      const lobbyRef = await addDoc(collection(db, 'lobbies'), {
        name: name || `${userProfile.username}'s Lobby`,
        hostId: currentUser.uid,
        participants: [hostParticipant],
        createdAt: Date.now(),
        code
      });
      
      // Update user's inLobby field
      await updateDoc(doc(db, 'users', currentUser.uid), {
        inLobby: lobbyRef.id
      });
      
      return lobbyRef.id;
    } catch (error) {
      console.error('Error creating lobby:', error);
      throw error;
    }
  };

  // Join a lobby by code
  const joinLobbyByCode = async (code: string) => {
    if (!currentUser || !userProfile) throw new Error('User not authenticated');

    try {
      // Find lobby with this code
      const lobbiesQuery = query(
        collection(db, 'lobbies'),
        where('code', '==', code.toUpperCase())
      );
      
      const lobbiesSnapshot = await getDocs(lobbiesQuery);
      
      if (lobbiesSnapshot.empty) {
        throw new Error('Lobby not found');
      }
      
      const lobbyDoc = lobbiesSnapshot.docs[0];
      const lobbyData = lobbyDoc.data();
      
      // Check if user is already in this lobby
      const isAlreadyParticipant = lobbyData.participants.some(
        (p: LobbyParticipant) => p.uid === currentUser.uid
      );
      
      if (isAlreadyParticipant) {
        // User is already in this lobby, just update their inLobby field
        await updateDoc(doc(db, 'users', currentUser.uid), {
          inLobby: lobbyDoc.id
        });
        
        return lobbyDoc.id;
      }
      
      // Create participant object
      const participant: LobbyParticipant = {
        uid: currentUser.uid,
        username: userProfile.username,
        displayName: userProfile.displayName,
        photoURL: userProfile.photoURL,
        isMuted: false,
        isHost: false
      };
      
      // Add user to lobby participants
      await updateDoc(doc(db, 'lobbies', lobbyDoc.id), {
        participants: arrayUnion(participant)
      });
      
      // Update user's inLobby field
      await updateDoc(doc(db, 'users', currentUser.uid), {
        inLobby: lobbyDoc.id
      });
      
      return lobbyDoc.id;
    } catch (error) {
      console.error('Error joining lobby by code:', error);
      throw error;
    }
  };

  // Join a lobby by ID
  const joinLobbyById = async (lobbyId: string) => {
    if (!currentUser || !userProfile) throw new Error('User not authenticated');

    try {
      // Get lobby document
      const lobbyDoc = await getDoc(doc(db, 'lobbies', lobbyId));
      
      if (!lobbyDoc.exists()) {
        throw new Error('Lobby not found');
      }
      
      const lobbyData = lobbyDoc.data();
      
      // Check if user is already in this lobby
      const isAlreadyParticipant = lobbyData.participants.some(
        (p: LobbyParticipant) => p.uid === currentUser.uid
      );
      
      if (isAlreadyParticipant) {
        // User is already in this lobby, just update their inLobby field
        await updateDoc(doc(db, 'users', currentUser.uid), {
          inLobby: lobbyId
        });
        
        return;
      }
      
      // Create participant object
      const participant: LobbyParticipant = {
        uid: currentUser.uid,
        username: userProfile.username,
        displayName: userProfile.displayName,
        photoURL: userProfile.photoURL,
        isMuted: false,
        isHost: false
      };
      
      // Add user to lobby participants
      await updateDoc(doc(db, 'lobbies', lobbyId), {
        participants: arrayUnion(participant)
      });
      
      // Update user's inLobby field
      await updateDoc(doc(db, 'users', currentUser.uid), {
        inLobby: lobbyId
      });
    } catch (error) {
      console.error('Error joining lobby by ID:', error);
      throw error;
    }
  };

  // Leave the current lobby
  const leaveLobby = async () => {
    if (!currentUser || !currentLobby) return;

    try {
      // Remove user from lobby participants
      const updatedParticipants = currentLobby.participants.filter(
        (p) => p.uid !== currentUser.uid
      );
      
      if (updatedParticipants.length === 0) {
        // Last user leaving, delete the lobby
        await deleteDoc(doc(db, 'lobbies', currentLobby.id));
      } else if (currentUser.uid === currentLobby.hostId) {
        // Host is leaving, assign a new host
        const newHost = updatedParticipants[0];
        newHost.isHost = true;
        
        await updateDoc(doc(db, 'lobbies', currentLobby.id), {
          participants: updatedParticipants,
          hostId: newHost.uid
        });
      } else {
        // Regular participant leaving
        await updateDoc(doc(db, 'lobbies', currentLobby.id), {
          participants: updatedParticipants
        });
      }
      
      // Update user's inLobby field
      await updateDoc(doc(db, 'users', currentUser.uid), {
        inLobby: null
      });
    } catch (error) {
      console.error('Error leaving lobby:', error);
      throw error;
    }
  };

  // Invite a friend to the current lobby
  const inviteFriend = async (friendId: string) => {
    if (!currentUser || !userProfile || !currentLobby) return;

    try {
      // Create invite
      const inviteId = uuidv4();
      const invite: LobbyInvite = {
        id: inviteId,
        lobbyId: currentLobby.id,
        lobbyName: currentLobby.name,
        inviterId: currentUser.uid,
        inviterName: userProfile.username,
        inviteeId: friendId,
        createdAt: Date.now()
      };
      
      await setDoc(doc(db, 'lobbyInvites', inviteId), invite);
    } catch (error) {
      console.error('Error inviting friend:', error);
      throw error;
    }
  };

  // Kick a participant from the lobby
  const kickParticipant = async (participantId: string) => {
    if (!currentUser || !currentLobby) return;

    // Only the host can kick participants
    if (currentUser.uid !== currentLobby.hostId) {
      throw new Error('Only the host can kick participants');
    }

    try {
      // Remove participant from lobby
      const updatedParticipants = currentLobby.participants.filter(
        (p) => p.uid !== participantId
      );
      
      await updateDoc(doc(db, 'lobbies', currentLobby.id), {
        participants: updatedParticipants
      });
      
      // Update kicked user's inLobby field
      await updateDoc(doc(db, 'users', participantId), {
        inLobby: null
      });
    } catch (error) {
      console.error('Error kicking participant:', error);
      throw error;
    }
  };

  // Toggle mute for a participant
  const toggleMute = async (participantId: string, muted: boolean) => {
    if (!currentUser || !currentLobby) return;

    try {
      // Update participant's muted status
      const updatedParticipants = currentLobby.participants.map((p) => {
        if (p.uid === participantId) {
          return { ...p, isMuted: muted };
        }
        return p;
      });
      
      await updateDoc(doc(db, 'lobbies', currentLobby.id), {
        participants: updatedParticipants
      });
    } catch (error) {
      console.error('Error toggling mute:', error);
      throw error;
    }
  };

  const value = {
    currentLobby,
    createLobby,
    joinLobbyByCode,
    joinLobbyById,
    leaveLobby,
    inviteFriend,
    kickParticipant,
    toggleMute,
    loading
  };

  return (
    <LobbyContext.Provider value={value}>
      {children}
    </LobbyContext.Provider>
  );
}