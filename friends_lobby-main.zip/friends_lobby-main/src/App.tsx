import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import LoginPage from './pages/LoginPage';
import ProfileSetupPage from './pages/ProfileSetupPage';
import HomePage from './pages/HomePage';
import LobbyPage from './pages/LobbyPage';
import ProtectedRoute from './components/auth/ProtectedRoute';
import NotificationContainer from './components/shared/NotificationContainer';

function App() {
  const { currentUser, userProfile, loading } = useAuth();

  useEffect(() => {
    // Update document title
    document.title = 'VoiceConnect';
  }, []);

  if (loading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-background">
        <div className="animate-pulse text-2xl font-semibold text-primary">
          Loading...
        </div>
      </div>
    );
  }

  return (
    <>
      <Routes>
        <Route path="/login" element={!currentUser ? <LoginPage /> : <Navigate to="/" />} />
        
        <Route 
          path="/setup-profile" 
          element={
            <ProtectedRoute>
              {currentUser && !userProfile?.username ? (
                <ProfileSetupPage />
              ) : (
                <Navigate to="/" />
              )}
            </ProtectedRoute>
          } 
        />
        
        <Route 
          path="/" 
          element={
            <ProtectedRoute>
              {currentUser && userProfile?.username ? (
                <HomePage />
              ) : currentUser ? (
                <Navigate to="/setup-profile" />
              ) : (
                <Navigate to="/login" />
              )}
            </ProtectedRoute>
          } 
        />
        
        <Route 
          path="/lobby/:lobbyId" 
          element={
            <ProtectedRoute>
              {currentUser && userProfile?.username ? (
                <LobbyPage />
              ) : currentUser ? (
                <Navigate to="/setup-profile" />
              ) : (
                <Navigate to="/login" />
              )}
            </ProtectedRoute>
          } 
        />
        
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>

      {currentUser && <NotificationContainer />}
    </>
  );
}

export default App;