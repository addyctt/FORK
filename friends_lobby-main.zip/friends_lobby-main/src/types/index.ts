// Firebase Auth User
export interface FirebaseUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

// User Profile
export interface UserProfile {
  uid: string;
  username: string;
  displayName?: string;
  email: string;
  photoURL: string;
  createdAt: number;
  friends: string[];
  isOnline?: boolean;
  inLobby?: string | null;
}

// Friend Request
export interface FriendRequest {
  id: string;
  senderId: string;
  receiverId: string;
  senderName: string;
  senderPhoto: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
}

// Lobby Participant
export interface LobbyParticipant {
  uid: string;
  username: string;
  displayName?: string;
  photoURL: string;
  isMuted: boolean;
  isHost: boolean;
}

// Lobby
export interface Lobby {
  id: string;
  name: string;
  hostId: string;
  participants: LobbyParticipant[];
  createdAt: number;
  code: string;
}

// Lobby Invite
export interface LobbyInvite {
  id: string;
  lobbyId: string;
  lobbyName: string;
  inviterId: string;
  inviterName: string;
  inviteeId: string;
  createdAt: number;
}

// Notification
export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'error' | 'warning' | 'invite' | 'request';
  data?: {
    lobbyId?: string;
    inviteId?: string;
    requestId?: string;
    [key: string]: any;
  };
  autoClose?: number | false;
}