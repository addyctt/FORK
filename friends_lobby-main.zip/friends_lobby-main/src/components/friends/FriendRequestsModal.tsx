import React from 'react';
import { X, UserPlus, UserMinus } from 'lucide-react';
import { useFriends } from '../../contexts/FriendContext';
import { useNotifications } from '../../contexts/NotificationContext';

interface FriendRequestsModalProps {
  onClose: () => void;
}

function FriendRequestsModal({ onClose }: FriendRequestsModalProps) {
  const { friendRequests, acceptFriendRequest, rejectFriendRequest } = useFriends();
  const { addNotification } = useNotifications();

  const handleAccept = async (requestId: string) => {
    try {
      await acceptFriendRequest(requestId);
      addNotification({
        title: 'Success',
        message: 'Friend request accepted',
        type: 'success',
        autoClose: 3000
      });
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to accept request',
        type: 'error',
        autoClose: 5000
      });
    }
  };

  const handleReject = async (requestId: string) => {
    try {
      await rejectFriendRequest(requestId);
      addNotification({
        title: 'Success',
        message: 'Friend request rejected',
        type: 'success',
        autoClose: 3000
      });
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to reject request',
        type: 'error',
        autoClose: 5000
      });
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div 
        className="modal-content max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground">Friend Requests</h2>
          <button
            onClick={onClose}
            className="rounded-full p-1 text-muted hover:bg-input hover:text-foreground"
          >
            <X size={20} />
          </button>
        </div>
        
        {friendRequests.length === 0 ? (
          <div className="py-8 text-center text-muted">
            <UserPlus size={48} className="mx-auto mb-4 text-muted" />
            <p>No pending friend requests</p>
          </div>
        ) : (
          <div className="space-y-4">
            {friendRequests.map((request) => (
              <div key={request.id} className="rounded-lg bg-input p-4">
                <div className="flex items-center">
                  <img
                    src={request.senderPhoto || ''}
                    alt={request.senderName}
                    className="h-12 w-12 rounded-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = 'https://via.placeholder.com/40';
                    }}
                  />
                  <div className="ml-3 flex-1">
                    <p className="font-medium text-foreground">{request.senderName}</p>
                    <p className="text-sm text-muted">
                      Sent {new Date(request.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleReject(request.id)}
                      className="rounded-md bg-input p-2 text-error hover:bg-opacity-80"
                      aria-label="Reject request"
                    >
                      <UserMinus size={20} />
                    </button>
                    <button
                      onClick={() => handleAccept(request.id)}
                      className="rounded-md bg-primary p-2 text-white hover:bg-primary-light"
                      aria-label="Accept request"
                    >
                      <UserPlus size={20} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default FriendRequestsModal;