import React, { useState } from 'react';
import { X, Search, UserPlus } from 'lucide-react';
import { useFriends } from '../../contexts/FriendContext';
import { useNotifications } from '../../contexts/NotificationContext';

interface AddFriendModalProps {
  onClose: () => void;
}

function AddFriendModal({ onClose }: AddFriendModalProps) {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { sendFriendRequest } = useFriends();
  const { addNotification } = useNotifications();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username.trim()) {
      addNotification({
        title: 'Error',
        message: 'Please enter a username',
        type: 'error',
        autoClose: 3000
      });
      return;
    }
    
    setLoading(true);
    
    try {
      await sendFriendRequest(username.trim());
      addNotification({
        title: 'Success',
        message: 'Friend request sent',
        type: 'success',
        autoClose: 3000
      });
      onClose();
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to send request',
        type: 'error',
        autoClose: 5000
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div 
        className="modal-content"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground">Add Friend</h2>
          <button
            onClick={onClose}
            className="rounded-full p-1 text-muted hover:bg-input hover:text-foreground"
          >
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="form-group">
            <label htmlFor="username" className="form-label">
              Username
            </label>
            <div className="relative">
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="input w-full pl-10"
                placeholder="Enter username"
                disabled={loading}
              />
              <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
            </div>
          </div>
          
          <button
            type="submit"
            className="btn btn-primary w-full"
            disabled={loading}
          >
            {loading ? 'Sending...' : 'Send Friend Request'}
          </button>
        </form>
        
        <div className="mt-6 text-center text-sm text-muted">
          <p>
            <UserPlus className="mr-1 inline-block h-4 w-4" />
            Friend requests are sent to users by their unique username
          </p>
        </div>
      </div>
    </div>
  );
}

export default AddFriendModal;