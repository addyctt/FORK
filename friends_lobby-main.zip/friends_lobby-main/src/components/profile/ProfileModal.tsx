import React, { useState, useRef } from 'react';
import { X, User, Upload, Check } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useNotifications } from '../../contexts/NotificationContext';

interface ProfileModalProps {
  onClose: () => void;
}

function ProfileModal({ onClose }: ProfileModalProps) {
  const { userProfile, updateProfile, checkUsernameAvailability } = useAuth();
  const { addNotification } = useNotifications();
  
  const [username, setUsername] = useState(userProfile?.username || '');
  const [isChecking, setIsChecking] = useState(false);
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUsernameChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.trim();
    setUsername(value);
    
    if (value === userProfile?.username) {
      setIsAvailable(null);
      return;
    }
    
    if (value.length < 3) {
      setIsAvailable(null);
      return;
    }
    
    setIsChecking(true);
    
    try {
      const available = await checkUsernameAvailability(value);
      setIsAvailable(available);
    } catch (error) {
      console.error('Error checking username:', error);
      setIsAvailable(null);
    } finally {
      setIsChecking(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    
    if (file) {
      setProfileImage(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (username.length < 3) {
      addNotification({
        title: 'Error',
        message: 'Username must be at least 3 characters',
        type: 'error',
        autoClose: 3000
      });
      return;
    }
    
    if (username !== userProfile?.username && !isAvailable) {
      addNotification({
        title: 'Error',
        message: 'Username is already taken',
        type: 'error',
        autoClose: 3000
      });
      return;
    }
    
    setLoading(true);
    
    try {
      await updateProfile({ 
        username: username !== userProfile?.username ? username : undefined
      }, profileImage || undefined);
      
      addNotification({
        title: 'Success',
        message: 'Profile updated successfully',
        type: 'success',
        autoClose: 3000
      });
      
      onClose();
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'An error occurred',
        type: 'error',
        autoClose: 5000
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div 
        className="modal-content"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground">Edit Profile</h2>
          <button
            onClick={onClose}
            className="rounded-full p-1 text-muted hover:bg-input hover:text-foreground"
          >
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-center">
            <div 
              className="relative h-24 w-24 cursor-pointer overflow-hidden rounded-full bg-input"
              onClick={() => fileInputRef.current?.click()}
            >
              {profileImagePreview ? (
                <img 
                  src={profileImagePreview} 
                  alt="Profile preview" 
                  className="h-full w-full object-cover"
                />
              ) : userProfile?.photoURL ? (
                <img 
                  src={userProfile.photoURL} 
                  alt="Profile" 
                  className="h-full w-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'https://via.placeholder.com/96';
                  }}
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-primary bg-opacity-10">
                  <User className="h-12 w-12 text-primary" />
                </div>
              )}
              
              <div className="absolute bottom-0 left-0 right-0 flex items-center justify-center bg-black bg-opacity-50 py-1 text-white">
                <Upload className="h-4 w-4" />
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageChange}
              />
            </div>
          </div>
          
          <div className="form-group">
            <label htmlFor="profile-username" className="form-label">
              Username
            </label>
            <div className="relative">
              <input
                id="profile-username"
                type="text"
                value={username}
                onChange={handleUsernameChange}
                className={`input w-full pr-10 ${
                  username !== userProfile?.username && (
                    isAvailable === true ? 'border-success' : 
                    isAvailable === false ? 'border-error' : ''
                  )
                }`}
                placeholder="Choose a username"
                minLength={3}
                maxLength={20}
                required
                disabled={loading}
              />
              
              {isChecking && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                </div>
              )}
              
              {!isChecking && username !== userProfile?.username && isAvailable === true && (
                <Check className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-success" />
              )}
              
              {!isChecking && username !== userProfile?.username && isAvailable === false && (
                <X className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-error" />
              )}
            </div>
            
            {username.length > 0 && username.length < 3 && (
              <p className="mt-1 text-sm text-error">
                Username must be at least 3 characters
              </p>
            )}
            
            {!isChecking && username !== userProfile?.username && isAvailable === false && (
              <p className="mt-1 text-sm text-error">
                Username is already taken
              </p>
            )}
            
            {!isChecking && username !== userProfile?.username && isAvailable === true && (
              <p className="mt-1 text-sm text-success">
                Username is available
              </p>
            )}
          </div>
          
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="btn btn-outline"
              disabled={loading}
            >
              Cancel
            </button>
            
            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading || (username !== userProfile?.username && isChecking) || (username !== userProfile?.username && isAvailable === false)}
            >
              {loading ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ProfileModal;