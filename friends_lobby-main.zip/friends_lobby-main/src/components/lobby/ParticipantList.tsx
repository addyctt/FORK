import React from 'react';
import { Volume2, VolumeX, UserMinus } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLobby } from '../../contexts/LobbyContext';
import { useNotifications } from '../../contexts/NotificationContext';

function ParticipantList() {
  const { currentUser } = useAuth();
  const { currentLobby, kickParticipant, toggleMute } = useLobby();
  const { addNotification } = useNotifications();

  const handleKick = async (participantId: string) => {
    try {
      await kickParticipant(participantId);
      addNotification({
        title: 'Success',
        message: 'Participant removed from lobby',
        type: 'success',
        autoClose: 3000
      });
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to remove participant',
        type: 'error',
        autoClose: 5000
      });
    }
  };

  const handleToggleMute = async (participantId: string, isMuted: boolean) => {
    try {
      await toggleMute(participantId, !isMuted);
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to toggle mute',
        type: 'error',
        autoClose: 5000
      });
    }
  };

  if (!currentLobby) {
    return (
      <div className="text-center text-muted">
        <p>No active lobby</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {currentLobby.participants.map((participant) => (
        <div
          key={participant.uid}
          className="flex items-center justify-between rounded-lg bg-input p-3"
        >
          <div className="flex items-center">
            <img
              src={participant.photoURL}
              alt={participant.username}
              className="h-10 w-10 rounded-full object-cover"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = 'https://via.placeholder.com/40';
              }}
            />
            <div className="ml-3">
              <div className="flex items-center">
                <span className="font-medium text-foreground">
                  {participant.username}
                </span>
                {participant.isHost && (
                  <span className="ml-2 rounded-full bg-primary px-2 py-0.5 text-xs font-medium text-white">
                    Host
                  </span>
                )}
                {participant.uid === currentUser?.uid && (
                  <span className="ml-2 rounded-full bg-secondary px-2 py-0.5 text-xs font-medium text-background">
                    You
                  </span>
                )}
              </div>
              <div className="text-xs text-muted">
                {participant.isMuted ? 'Muted' : 'Speaking'}
              </div>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <button
              onClick={() => handleToggleMute(participant.uid, participant.isMuted)}
              className={`rounded-full p-2 ${
                participant.isMuted
                  ? 'bg-input text-muted hover:text-foreground'
                  : 'bg-primary text-white'
              }`}
              aria-label={participant.isMuted ? 'Unmute' : 'Mute'}
            >
              {participant.isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
            </button>
            
            {currentLobby.hostId === currentUser?.uid && participant.uid !== currentUser?.uid && (
              <button
                onClick={() => handleKick(participant.uid)}
                className="rounded-full bg-input p-2 text-error hover:bg-error hover:text-white"
                aria-label="Kick from lobby"
              >
                <UserMinus size={18} />
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

export default ParticipantList;