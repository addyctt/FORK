import React, { useState, useEffect } from 'react';
import { Mic, MicOff, PhoneOff } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLobby } from '../../contexts/LobbyContext';
import { useNavigate } from 'react-router-dom';

function VoiceControls() {
  const [muted, setMuted] = useState(false);
  
  const { currentUser } = useAuth();
  const { currentLobby, toggleMute, leaveLobby } = useLobby();
  const navigate = useNavigate();

  // Check initial mute state from lobby data
  useEffect(() => {
    if (currentLobby && currentUser) {
      const userParticipant = currentLobby.participants.find(
        (p) => p.uid === currentUser.uid
      );
      if (userParticipant) {
        setMuted(userParticipant.isMuted);
      }
    }
  }, [currentLobby, currentUser]);

  const handleToggleMute = async () => {
    if (!currentUser) return;
    
    try {
      await toggleMute(currentUser.uid, !muted);
      setMuted(!muted);
    } catch (error) {
      console.error('Error toggling mute:', error);
    }
  };

  const handleLeaveLobby = async () => {
    try {
      await leaveLobby();
      navigate('/');
    } catch (error) {
      console.error('Error leaving lobby:', error);
    }
  };

  return (
    <div className="flex items-center justify-center space-x-4">
      <button
        onClick={handleToggleMute}
        className={`flex h-12 w-12 items-center justify-center rounded-full ${
          muted
            ? 'bg-input text-muted hover:bg-primary hover:bg-opacity-10 hover:text-primary'
            : 'bg-primary text-white hover:bg-primary-light'
        }`}
        aria-label={muted ? 'Unmute' : 'Mute'}
      >
        {muted ? <MicOff size={24} /> : <Mic size={24} />}
      </button>
      
      <button
        onClick={handleLeaveLobby}
        className="flex h-12 w-12 items-center justify-center rounded-full bg-error text-white hover:bg-opacity-90"
        aria-label="Leave lobby"
      >
        <PhoneOff size={24} />
      </button>
    </div>
  );
}

export default VoiceControls;