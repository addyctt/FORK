import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User, 
  UserPlus, 
  Bell, 
  Plus, 
  Settings,
  LogOut
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useFriends } from '../../contexts/FriendContext';
import { useLobby } from '../../contexts/LobbyContext';
import { useNotifications } from '../../contexts/NotificationContext';
import FriendRequestsModal from '../friends/FriendRequestsModal';
import AddFriendModal from '../friends/AddFriendModal';

interface SidebarProps {
  onProfileClick: () => void;
}

function Sidebar({ onProfileClick }: SidebarProps) {
  const [expanded, setExpanded] = useState(false);
  const [collapseTimeout, setCollapseTimeout] = useState<NodeJS.Timeout | null>(null);
  const [showFriendRequests, setShowFriendRequests] = useState(false);
  const [showAddFriend, setShowAddFriend] = useState(false);
  
  const sidebarRef = useRef<HTMLDivElement>(null);
  
  const { currentUser, userProfile, logOut } = useAuth();
  const { friends, friendRequests } = useFriends();
  const { createLobby, inviteFriend, currentLobby } = useLobby();
  const { addNotification } = useNotifications();
  const navigate = useNavigate();

  // Handle automatic collapse
  useEffect(() => {
    return () => {
      if (collapseTimeout) {
        clearTimeout(collapseTimeout);
      }
    };
  }, [collapseTimeout]);

  // Handle click outside to collapse sidebar
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (expanded && sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        setExpanded(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [expanded]);

  const handleExpand = () => {
    setExpanded(true);
    
    // Clear any existing timeout
    if (collapseTimeout) {
      clearTimeout(collapseTimeout);
      setCollapseTimeout(null);
    }
  };

  const handleMouseLeave = () => {
    // Set timeout to collapse after 3 seconds
    const timeout = setTimeout(() => {
      setExpanded(false);
    }, 3000);
    
    setCollapseTimeout(timeout);
  };

  const handleMouseEnter = () => {
    // Clear timeout when mouse enters again
    if (collapseTimeout) {
      clearTimeout(collapseTimeout);
      setCollapseTimeout(null);
    }
  };

  const handleInviteFriend = async (friendId: string) => {
    try {
      // If not in a lobby, create one first
      if (!currentLobby) {
        const lobbyId = await createLobby();
        await inviteFriend(friendId);
        navigate(`/lobby/${lobbyId}`);
      } else {
        // Already in a lobby, just invite
        await inviteFriend(friendId);
      }
      
      addNotification({
        title: 'Success',
        message: 'Invitation sent',
        type: 'success',
        autoClose: 3000
      });
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to invite friend',
        type: 'error',
        autoClose: 5000
      });
    }
  };

  const handleLogout = async () => {
    try {
      await logOut();
      navigate('/login');
    } catch (error) {
      addNotification({
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to log out',
        type: 'error',
        autoClose: 5000
      });
    }
  };

  return (
    <>
      <div
        ref={sidebarRef}
        className={`sidebar flex h-full flex-col bg-card transition-all duration-300 ${
          expanded ? 'sidebar-expanded' : 'sidebar-collapsed'
        }`}
        onMouseEnter={() => {
          handleMouseEnter();
          handleExpand();
        }}
        onMouseLeave={handleMouseLeave}
      >
        <div className="flex h-16 items-center justify-between border-b border-border px-4">
          {expanded ? (
            <h1 className="text-xl font-bold text-foreground">VoiceConnect</h1>
          ) : (
            <div className="mx-auto h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-white font-bold">V</span>
            </div>
          )}
        </div>
        
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Friends Section */}
          <div className="mb-2 overflow-y-auto p-2">
            {expanded && (
              <div className="mb-3 flex items-center justify-between px-2">
                <h2 className="text-sm font-medium text-muted">Friends</h2>
                <button 
                  onClick={() => setShowAddFriend(true)}
                  className="rounded-full p-1 text-muted hover:bg-input hover:text-foreground"
                  aria-label="Add friend"
                >
                  <UserPlus size={16} />
                </button>
              </div>
            )}
            
            {friends.length === 0 ? (
              expanded && (
                <div className="mt-4 text-center text-sm text-muted">
                  No friends yet
                </div>
              )
            ) : (
              <div className="space-y-2">
                {friends.map((friend) => (
                  <div
                    key={friend.uid}
                    className={`group flex items-center rounded-lg p-2 ${
                      expanded ? 'justify-between' : 'justify-center'
                    } hover:bg-input`}
                  >
                    <div className="flex items-center">
                      <div className="relative">
                        <img
                          src={friend.photoURL || ''}
                          alt={friend.username}
                          className="h-10 w-10 rounded-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = 'https://via.placeholder.com/40';
                          }}
                        />
                        <span
                          className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-card ${
                            friend.isOnline ? 'bg-success' : 'bg-muted'
                          }`}
                        ></span>
                      </div>
                      
                      {expanded && (
                        <span className="ml-3 text-foreground">{friend.username}</span>
                      )}
                    </div>
                    
                    {expanded && (
                      <button
                        onClick={() => handleInviteFriend(friend.uid)}
                        className="opacity-0 group-hover:opacity-100 rounded-full p-1 text-primary hover:bg-primary hover:bg-opacity-10"
                        aria-label="Invite to lobby"
                      >
                        <Plus size={18} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        {/* Bottom Buttons */}
        <div className="border-t border-border p-2">
          {/* Friend Requests Button */}
          <button
            onClick={() => setShowFriendRequests(true)}
            className={`relative mb-2 flex w-full items-center rounded-lg p-2 ${
              expanded ? 'justify-start' : 'justify-center'
            } hover:bg-input`}
          >
            <Bell size={expanded ? 20 : 24} className="text-foreground" />
            
            {friendRequests.length > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-white">
                {friendRequests.length}
              </span>
            )}
            
            {expanded && <span className="ml-3 text-foreground">Friend Requests</span>}
          </button>
          
          {/* Profile Button */}
          <button
            onClick={onProfileClick}
            className={`mb-2 flex w-full items-center rounded-lg p-2 ${
              expanded ? 'justify-start' : 'justify-center'
            } hover:bg-input`}
          >
            <User size={expanded ? 20 : 24} className="text-foreground" />
            {expanded && <span className="ml-3 text-foreground">Profile</span>}
          </button>
          
          {/* Settings Button */}
          <button
            className={`mb-2 flex w-full items-center rounded-lg p-2 ${
              expanded ? 'justify-start' : 'justify-center'
            } hover:bg-input`}
          >
            <Settings size={expanded ? 20 : 24} className="text-foreground" />
            {expanded && <span className="ml-3 text-foreground">Settings</span>}
          </button>
          
          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className={`flex w-full items-center rounded-lg p-2 ${
              expanded ? 'justify-start' : 'justify-center'
            } text-error hover:bg-input`}
          >
            <LogOut size={expanded ? 20 : 24} />
            {expanded && <span className="ml-3">Logout</span>}
          </button>
        </div>
      </div>
      
      {showFriendRequests && (
        <FriendRequestsModal onClose={() => setShowFriendRequests(false)} />
      )}
      
      {showAddFriend && (
        <AddFriendModal onClose={() => setShowAddFriend(false)} />
      )}
    </>
  );
}

export default Sidebar;