import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Check } from 'lucide-react';
import { useNotifications, Notification } from '../../contexts/NotificationContext';
import { useLobby } from '../../contexts/LobbyContext';
import { useFriends } from '../../contexts/FriendContext';

function NotificationContainer() {
  const { notifications, removeNotification } = useNotifications();
  const { joinLobbyById } = useLobby();
  const { acceptFriendRequest, rejectFriendRequest } = useFriends();
  const navigate = useNavigate();

  const handleAcceptInvite = async (notification: Notification) => {
    if (!notification.data?.lobbyId) return;
    
    try {
      await joinLobbyById(notification.data.lobbyId);
      navigate(`/lobby/${notification.data.lobbyId}`);
      removeNotification(notification.id);
    } catch (error) {
      console.error('Error accepting invite:', error);
    }
  };

  const handleAcceptFriendRequest = async (notification: Notification) => {
    if (!notification.data?.requestId) return;
    
    try {
      await acceptFriendRequest(notification.data.requestId);
      removeNotification(notification.id);
    } catch (error) {
      console.error('Error accepting friend request:', error);
    }
  };

  const handleRejectFriendRequest = async (notification: Notification) => {
    if (!notification.data?.requestId) return;
    
    try {
      await rejectFriendRequest(notification.data.requestId);
      removeNotification(notification.id);
    } catch (error) {
      console.error('Error rejecting friend request:', error);
    }
  };

  return (
    <div className="fixed right-4 top-4 z-50 flex flex-col items-end space-y-4">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className="w-80 max-w-md overflow-hidden rounded-lg bg-card shadow-lg"
        >
          <div className={`flex items-center px-4 py-2 ${
            notification.type === 'error' ? 'bg-error' :
            notification.type === 'success' ? 'bg-success' :
            notification.type === 'warning' ? 'bg-warning' :
            notification.type === 'invite' ? 'bg-primary' :
            notification.type === 'request' ? 'bg-secondary' :
            'bg-primary'
          }`}>
            <span className="text-sm font-medium text-white">
              {notification.title}
            </span>
            <button
              onClick={() => removeNotification(notification.id)}
              className="ml-auto text-white"
            >
              <X size={16} />
            </button>
          </div>
          
          <div className="p-4">
            <p className="text-sm text-foreground">{notification.message}</p>
            
            {(notification.type === 'invite' || notification.type === 'request') && (
              <div className="mt-3 flex justify-end space-x-2">
                <button
                  onClick={() => removeNotification(notification.id)}
                  className="rounded-md bg-muted px-3 py-1 text-xs font-medium text-foreground"
                >
                  Dismiss
                </button>
                
                {notification.type === 'invite' && (
                  <button
                    onClick={() => handleAcceptInvite(notification)}
                    className="rounded-md bg-primary px-3 py-1 text-xs font-medium text-white"
                  >
                    Accept
                  </button>
                )}
                
                {notification.type === 'request' && (
                  <>
                    <button
                      onClick={() => handleRejectFriendRequest(notification)}
                      className="rounded-md bg-error px-3 py-1 text-xs font-medium text-white"
                    >
                      Reject
                    </button>
                    <button
                      onClick={() => handleAcceptFriendRequest(notification)}
                      className="rounded-md bg-success px-3 py-1 text-xs font-medium text-white"
                    >
                      Accept
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

export default NotificationContainer;